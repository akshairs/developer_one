# from odoo import models, fields
#
#
# class PerformanceReportWizard(models.TransientModel):
#     _name = 'performance.report.wizard'
#     _description = 'Performance Monitoring Report Wizard'
#
#     from_date = fields.Date(required=True)
#     to_date = fields.Date(required=True)
#
#     company_id = fields.Many2one(
#         'res.company',
#         default=lambda self: self.env.company,
#         required=True
#     )
#
#     branch_id = fields.Many2one(
#         'res.company',
#         string='Branch',
#         required=True
#     )
#
#     report_type = fields.Selection([
#         ('salesman', 'Salesperson-wise'),
#         ('department', 'Department-wise'),
#         ('customer', 'Customer-wise'),
#     ], default='salesman', required=True)
#
#
#     def action_preview(self):
#         self.ensure_one()
#
#         Preview = self.env['performance.report.preview']
#         Shipment = self.env['ship.shipment']
#
#
#         Preview.search([('create_uid', '=', self.env.uid)]).unlink()
#
#         # domain = [
#         #     ('branch_id', '=', self.branch_id.id),
#         #     ('booking_id.create_date', '>=', self.from_date),
#         #     ('booking_id.create_date', '<=', self.to_date),
#         # ]
#         domain = [
#             ('company_id', '=', self.company_id.id),
#             ('hbl_date', '>=', self.from_date),
#             ('hbl_date', '<=', self.to_date),
#         ]
#         shipments = Shipment.search(domain)
#
#         #shipments = self.env['ship.shipment'].search(domain)
#
#         print("FINAL DOMAIN:", domain)
#         print("FETCHED SHIPMENTS:", shipments.ids)
#
#
#         if not shipments:
#             Preview.create({
#                 'level_1': 'NO DATA',
#                 'job_no': '',
#                 'income': 0,
#                 'expense': 0,
#                 'profit': 0,
#                 'from_date': self.from_date,
#                 'to_date': self.to_date,
#                 'report_type': self.report_type,
#             })
#
#         for ship in shipments:
#             income = ship.income or 0
#             expense = ship.expense or 0
#
#             salesman = ship.booking_id.create_uid.name if ship.booking_id else ''
#             department = ship.department_id.name if ship.department_id else ''
#             customer = ship.hbl_customer_id.name if ship.hbl_customer_id else ''
#
#             if self.report_type == 'salesman':
#                 l1, l2, l3 = salesman, department, customer
#             elif self.report_type == 'department':
#                 l1, l2, l3 = department, salesman, customer
#             else:
#                 l1, l2, l3 = customer, salesman, ''
#
#             Preview.create({
#                 'level_1': l1,
#                 'level_2': l2,
#                 'level_3': l3,
#                 'job_no': ship.name,
#                 'income': income,
#                 'expense': expense,
#                 'profit': income - expense,
#                 'from_date': self.from_date,
#                 'to_date': self.to_date,
#                 'report_type': self.report_type,
#             })
#
#         # return self.env.ref(
#         #     'performance_report.action_performance_report'
#         # ).report_action(
#         #     Preview.search([('create_uid', '=', self.env.uid)])
#         # )
#         return self.env.ref(
#             'performance_report.action_performance_report'
#         ).report_action(
#             Preview.search([('create_uid', '=', self.env.uid)])
#         )
#
#
# class PerformanceReportPreview(models.TransientModel):
#     _name = 'performance.report.preview'
#     _description = 'Performance Report Preview'
#
#     level_1 = fields.Char()
#     level_2 = fields.Char()
#     level_3 = fields.Char()
#
#     job_no = fields.Char()
#     income = fields.Float()
#     expense = fields.Float()
#     profit = fields.Float()
#
#     from_date = fields.Date()
#     to_date = fields.Date()
#     report_type = fields.Selection([
#         ('salesman', 'Salesperson-wise'),
#         ('department', 'Department-wise'),
#         ('customer', 'Customer-wise'),
#     ])
from odoo import models, fields


class PerformanceReportWizard(models.TransientModel):
    _name = 'performance.report.wizard'
    _description = 'Performance Monitoring Report Wizard'

    from_date = fields.Date(required=True)
    to_date = fields.Date(required=True)

    company_id = fields.Many2one(
        'res.company',
        default=lambda self: self.env.company,
        required=True
    )

    branch_id = fields.Many2one(
        'res.company',
        string='Branch',
        required=True
    )

    report_type = fields.Selection([
        ('salesman', 'Salesperson-wise'),
        ('department', 'Department-wise'),
        ('customer', 'Customer-wise'),
    ], default='salesman', required=True)


    def _prepare_preview_data(self):
        Preview = self.env['performance.report.preview']
        Shipment = self.env['ship.shipment']

        Preview.search([('create_uid', '=', self.env.uid)]).unlink()

        domain = [
            ('company_id', '=', self.company_id.id),
            ('hbl_date', '>=', self.from_date),
            ('hbl_date', '<=', self.to_date),
        ]

        shipments = Shipment.search(domain)

        if not shipments:
            Preview.create({
                'level_1': 'NO DATA',
                'income': 0,
                'expense': 0,
                'profit': 0,
                'from_date': self.from_date,
                'to_date': self.to_date,
                'report_type': self.report_type,
            })
            return

        for ship in shipments:
            income = ship.income or 0
            expense = ship.expense or 0

            salesman = ship.booking_id.create_uid.name if ship.booking_id else ''
            department = ship.department_id.name if ship.department_id else ''
            customer = ship.hbl_customer_id.name if ship.hbl_customer_id else ''

            if self.report_type == 'salesman':
                l1, l2, l3 = salesman, department, customer
            elif self.report_type == 'department':
                l1, l2, l3 = department, salesman, customer
            else:
                l1, l2, l3 = customer, salesman, ''

            Preview.create({
                'level_1': l1,
                'level_2': l2,
                'level_3': l3,
                'job_no': ship.name,
                'income': income,
                'expense': expense,
                'profit': income - expense,
                'from_date': self.from_date,
                'to_date': self.to_date,
                'report_type': self.report_type,
            })



    def action_preview_html(self):
        self.ensure_one()
        self._prepare_preview_data()

        return self.env.ref(
            'performance_report.action_performance_report_html'
        ).report_action(
            self.env['performance.report.preview'].search(
                [('create_uid', '=', self.env.uid)]
            )
        )


    def action_print_pdf(self):
        self.ensure_one()
        self._prepare_preview_data()

        return self.env.ref(
            'performance_report.action_performance_report_pdf'
        ).report_action(
            self.env['performance.report.preview'].search(
                [('create_uid', '=', self.env.uid)]
            )
        )

    def action_print_xlsx(self):
        self.ensure_one()
        self._prepare_preview_data()

        return self.env.ref(
            'performance_report.action_performance_report_xlsx'
        ).report_action(
            self.env['performance.report.preview'].search(
                [('create_uid', '=', self.env.uid)]
            )
        )


class PerformanceReportPreview(models.TransientModel):
    _name = 'performance.report.preview'
    _description = 'Performance Report Preview'

    level_1 = fields.Char()
    level_2 = fields.Char()
    level_3 = fields.Char()

    job_no = fields.Char()
    income = fields.Float()
    expense = fields.Float()
    profit = fields.Float()

    from_date = fields.Date()
    to_date = fields.Date()
    report_type = fields.Selection([
        ('salesman', 'Salesperson-wise'),
        ('department', 'Department-wise'),
        ('customer', 'Customer-wise'),
    ])



