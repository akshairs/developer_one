{
    'name': 'Performance Monitoring Report',
    'version': '1.0',
    'category': 'Reports',
    'summary': 'Salesperson / Department / Customer wise performance report',
    'author': 'Your Company',

    'depends': [
        'base',
        'web',
        'shipping_proxy',
    ],

    'data': [
        'security/ir.model.access.csv',

        'wizard/performance_report_wizard_view.xml',
        'views/performance_report_menu.xml',

        'report/performance_report_action.xml',
        'report/performance_report_template.xml',
        'report/performance_report_xlsx.xml',
    ],

    'installable': True,
    'application': False,
}
