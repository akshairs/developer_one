from odoo import models


class PerformanceReportXlsx(models.AbstractModel):
    _name = 'report.performance_report.performance_report_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, records):
        sheet = workbook.add_worksheet('Performance Report')

        header = workbook.add_format({
            'bold': True,
            'border': 1,
            'align': 'center'
        })

        normal = workbook.add_format({'border': 1})

        headers = [
            'Group 1', 'Group 2', 'Group 3',
            'Job No', 'Income', 'Expense', 'Profit'
        ]

        for col, h in enumerate(headers):
            sheet.write(0, col, h, header)
            sheet.set_column(col, col, 18)

        row = 1
        for r in records:
            sheet.write(row, 0, r.level_1 or '', normal)
            sheet.write(row, 1, r.level_2 or '', normal)
            sheet.write(row, 2, r.level_3 or '', normal)
            sheet.write(row, 3, r.job_no or '', normal)
            sheet.write(row, 4, r.income or 0, normal)
            sheet.write(row, 5, r.expense or 0, normal)
            sheet.write(row, 6, r.profit or 0, normal)
            row += 1
